# Roadvanta
Android game (WebView + AdMob). Build the APK with GitHub Actions: Actions > Build APK > Run workflow > download the APK from Artifacts.
