package com.roadvanta.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import com.google.android.gms.ads.*;
import com.google.android.gms.ads.interstitial.*;
import com.google.android.gms.ads.rewarded.*;

public class MainActivity extends Activity {
  // Roadvanta AdMob unit ids
  static final String BANNER = "ca-app-pub-5059428712375364/8781770814";
  static final String INTER  = "ca-app-pub-5059428712375364/6155607473";
  static final String REWARD = "ca-app-pub-5059428712375364/9123330401";
  WebView web; AdView banner; InterstitialAd inter; RewardedAd rew; boolean earned;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    FrameLayout root = new FrameLayout(this);
    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    web.addJavascriptInterface(new Bridge(), "AndroidAds");
    root.addView(web, new FrameLayout.LayoutParams(-1, -1));
    banner = new AdView(this); banner.setAdSize(AdSize.BANNER); banner.setAdUnitId(BANNER); banner.setVisibility(View.GONE);
    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
    root.addView(banner, lp);
    setContentView(root);
    MobileAds.initialize(this, st -> {});
    banner.loadAd(new AdRequest.Builder().build());
    loadInter(); loadRew();
    web.loadUrl("file:///android_asset/index.html");
  }

  void js(String c) { runOnUiThread(() -> web.evaluateJavascript(c, null)); }
  void loadInter() {
    InterstitialAd.load(this, INTER, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
      @Override public void onAdLoaded(InterstitialAd a) { inter = a; }
      @Override public void onAdFailedToLoad(LoadAdError e) { inter = null; } });
  }
  void loadRew() {
    RewardedAd.load(this, REWARD, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
      @Override public void onAdLoaded(RewardedAd a) { rew = a; }
      @Override public void onAdFailedToLoad(LoadAdError e) { rew = null; } });
  }

  class Bridge {
    @JavascriptInterface public void showInterstitial() {
      runOnUiThread(() -> {
        if (inter == null) { js("window._adcb&&_adcb()"); loadInter(); return; }
        inter.setFullScreenContentCallback(new FullScreenContentCallback() {
          @Override public void onAdDismissedFullScreenContent() { inter = null; js("window._adcb&&_adcb()"); loadInter(); }
          @Override public void onAdFailedToShowFullScreenContent(AdError e) { inter = null; js("window._adcb&&_adcb()"); loadInter(); } });
        inter.show(MainActivity.this);
      });
    }
    @JavascriptInterface public void showRewarded() {
      runOnUiThread(() -> {
        if (rew == null) { js("window._adr&&_adr(false)"); loadRew(); return; }
        earned = false;
        rew.setFullScreenContentCallback(new FullScreenContentCallback() {
          @Override public void onAdDismissedFullScreenContent() { rew = null; js("window._adr&&_adr(" + earned + ")"); loadRew(); }
          @Override public void onAdFailedToShowFullScreenContent(AdError e) { rew = null; js("window._adr&&_adr(false)"); loadRew(); } });
        rew.show(MainActivity.this, item -> earned = true);
      });
    }
    @JavascriptInterface public void banner(boolean on) { runOnUiThread(() -> banner.setVisibility(on ? View.VISIBLE : View.GONE)); }
  }

  @Override public void onWindowFocusChanged(boolean f) {
    super.onWindowFocusChanged(f);
    if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  }
  // Back button pauses the game instead of closing the app
  @Override public void onBackPressed() { js("try{pauseOn()}catch(e){}"); }
  @Override protected void onPause() { super.onPause(); web.onPause(); }
  @Override protected void onResume() { super.onResume(); web.onResume(); }
}
